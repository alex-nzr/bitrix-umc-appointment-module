<?php
$MESS["ANZ_APPOINTMENT_DEMO_MODE_ERROR"] = "Demo mode error: ";