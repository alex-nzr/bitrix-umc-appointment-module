<?php
$MESS['ANZ_APPOINTMENT_CONTAINER_CLASSNAME_ERROR'] = "className should be a valid string";