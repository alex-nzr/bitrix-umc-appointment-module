<?php
const ADMIN_MODULE_NAME = "anz.appointment";