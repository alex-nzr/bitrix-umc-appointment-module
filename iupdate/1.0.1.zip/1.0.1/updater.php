<?
$updater->CopyFiles("install/js", "js/anz/appointment");
$updater->CopyFiles("install/components", "components");
?>