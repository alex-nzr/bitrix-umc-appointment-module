<?
$arModuleVersion = array(
	"VERSION" => "1.0.2",
	"VERSION_DATE" => "2022-07-22 20:01:26"
);
?>