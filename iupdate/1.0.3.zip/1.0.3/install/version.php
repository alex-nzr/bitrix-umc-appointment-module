<?
$arModuleVersion = array(
	"VERSION" => "1.0.3",
	"VERSION_DATE" => "2022-07-27 23:02:03"
);
?>