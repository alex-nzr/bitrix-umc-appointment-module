<?php
$MESS['FIRSTBIT_APPOINTMENT_COMPONENT_NAME'] = "Форма создания записи";
$MESS['FIRSTBIT_APPOINTMENT_COMPONENT_DESC'] = "Создание записи на приём в БИТ.УМЦ";
$MESS['FIRSTBIT_APPOINTMENT_VENDOR_NAME']    = "Первый Бит";
$MESS['FIRSTBIT_APPOINTMENT_CATEGORY_NAME']  = "Запись на приём";