<?php
$MESS["FIRSTBIT_APPOINTMENT_COMPONENT_ACCESS_DENIED"] = "Доступ к форме записи закрыт";
$MESS["FIRSTBIT_APPOINTMENT_MODULE_NOT_INCLUDED"] = "Не удалось подключить модуль записи на приём";
