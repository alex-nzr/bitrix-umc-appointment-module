<?php
$MESS['FIRSTBIT_APPOINTMENT_POPUP_EXTENSION_ERROR'] = "Ошибка при подключении расширения компонента";
