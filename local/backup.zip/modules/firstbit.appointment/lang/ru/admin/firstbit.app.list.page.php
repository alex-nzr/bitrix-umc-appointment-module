<?php
$MESS['FIRSTBIT_APPOINTMENT_MODULE_NOT_LOADED'] = "Не удалось подключить модуль записи на приём";
$MESS["FIRSTBIT_APPOINTMENT_ACCESS_DENIED"] = "Доступ к модулю запрещён";
$MESS['FIRSTBIT_ADMIN_LIST_PAGE_TITLE'] = "Список записей на приём";
