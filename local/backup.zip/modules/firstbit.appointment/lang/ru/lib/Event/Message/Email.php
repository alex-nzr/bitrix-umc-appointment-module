<?php
$MESS["FIRSTBIT_APPOINTMENT_EMAIL_NOTE_NAME"]       = "Email оповещение о записи на приём";
$MESS["FIRSTBIT_APPOINTMENT_NOTE_DESC_TEXT"]        = "Текст сообщения";
$MESS["FIRSTBIT_APPOINTMENT_NOTE_DESC_EMAIL_TO"]    = "Email получателя";
$MESS["FIRSTBIT_APPOINTMENT_EMAIL_CONFIRM_NAME"]    = "Email-подтверждение";
$MESS["FIRSTBIT_APPOINTMENT_CONFIRM_DESC_CODE"]     = "Код подтверждения";