<?php
$MESS["FIRSTBIT_APPOINTMENT_CLIENT_FAILED"] = "Error on creation web client";