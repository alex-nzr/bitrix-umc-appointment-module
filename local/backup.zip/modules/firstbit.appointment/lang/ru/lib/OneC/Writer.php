<?php
$MESS["FIRSTBIT_APPOINTMENT_REQUIRED_PARAMS_ERROR"] = "Not enough params to make appointment";
$MESS["FIRSTBIT_APPOINTMENT_RESERVE_ERROR"] = "Error on creating reserve in 1C";
$MESS['FIRSTBIT_APPOINTMENT_WAITING_LIST_COMMENT'] =
"Запрос с сайта
______________________________________ 
    
#FULL_NAME#
#PHONE#
#COMMENT#   
    
Желаемая дата: #DATE#
Желаемое время: #TIME#";