<?php
$MESS["FIRSTBIT_APPOINTMENT_MESSAGE_NOTE"] = "
Вы успешно записались на приём
Клиника: #CLINIC#
Специализация: #SPECIALTY#
Услуги: #SERVICE#
Врач: #DOCTOR#
Дата/время: #DATETIME#
ФИО: #NAME#
Номер телефона: #PHONE#
Комментарий: #COMMENT#
";