<?php
$MESS["FIRSTBIT_APPOINTMENT_CONFIRM_TYPE_ERROR"] = "Тип подтверждения записи не выбран или некорректен";
$MESS['FIRSTBIT_APPOINTMENT_CONFIRM_CODE_NOT_EXPIRED'] = 'Запрашивать код подтверждения можно не чаще, чем раз в минуту';
$MESS['FIRSTBIT_APPOINTMENT_CONFIRM_CODE_EXPIRED'] = 'Время действия кода подтверждения истекло';
$MESS['FIRSTBIT_APPOINTMENT_CONFIRM_CODE_INCORRECT'] = 'Неверный код подтверждения';