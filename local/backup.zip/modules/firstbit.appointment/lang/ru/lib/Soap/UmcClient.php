<?php
$MESS["FIRSTBIT_APPOINTMENT_SOAP_EXT_NOT_FOUND"] = "php-SOAP extension is not installed";
$MESS['FIRSTBIT_APPOINTMENT_SOAP_AUTH_ERROR'] = "Soap auth data is empty, check module setting";
$MESS['FIRSTBIT_APPOINTMENT_SOAP_URL_ERROR'] = "Soap url is empty, check module setting";