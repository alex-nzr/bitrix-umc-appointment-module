<?php
const ADMIN_MODULE_NAME = "firstbit.appointment";